import React from 'react';
import { CartProvider } from './context/CartContext';
import Header from './components/Header';
import Hero from './components/Hero';
import MealsSection from './components/MealsSection';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <CartProvider>
      <div className="min-h-screen">
        <Header />
        <Hero />
        <MealsSection />
        <About />
        <Contact />
        <Footer />
      </div>
    </CartProvider>
  );
}

export default App;