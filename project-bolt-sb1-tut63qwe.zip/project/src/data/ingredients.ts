import { MealIngredient, MealSize } from '../types/meal';

export const mealSizes: MealSize[] = [
  {
    id: 'small',
    name: 'Small',
    weight: '250g',
    servings: '1-2 servings',
    multiplier: 1
  },
  {
    id: 'medium',
    name: 'Medium',
    weight: '500g',
    servings: '3-4 servings',
    multiplier: 1.8
  },
  {
    id: 'large',
    name: 'Large',
    weight: '1kg',
    servings: '6-8 servings',
    multiplier: 3.2
  }
];

export const proteins: MealIngredient[] = [
  {
    id: 'chicken',
    name: 'Fresh Chicken',
    category: 'protein',
    price: 45,
    unit: 'per serving',
    description: 'Lean, high-quality chicken breast and thigh',
    emoji: '🐔',
    nutritionalBenefits: ['High protein', 'Low fat', 'Rich in B vitamins']
  },
  {
    id: 'fish',
    name: 'Fresh Fish',
    category: 'protein',
    price: 65,
    unit: 'per serving',
    description: 'Wild-caught fish rich in omega-3',
    emoji: '🐟',
    nutritionalBenefits: ['Omega-3 fatty acids', 'High protein', 'Brain health']
  },
  {
    id: 'lamb',
    name: 'Premium Lamb',
    category: 'protein',
    price: 85,
    unit: 'per serving',
    description: 'Grass-fed lamb for sensitive stomachs',
    emoji: '🐑',
    nutritionalBenefits: ['High protein', 'Iron rich', 'Hypoallergenic']
  },
  {
    id: 'turkey',
    name: 'Fresh Turkey',
    category: 'protein',
    price: 55,
    unit: 'per serving',
    description: 'Lean turkey breast and ground turkey',
    emoji: '🦃',
    nutritionalBenefits: ['Lean protein', 'Low calories', 'Rich in selenium']
  },
  {
    id: 'beef',
    name: 'Grass-Fed Beef',
    category: 'protein',
    price: 75,
    unit: 'per serving',
    description: 'Premium grass-fed beef cuts',
    emoji: '🐄',
    nutritionalBenefits: ['High protein', 'Iron rich', 'B12 vitamins']
  }
];

export const carbs: MealIngredient[] = [
  {
    id: 'sweet-potato',
    name: 'Sweet Potato',
    category: 'carb',
    price: 15,
    unit: 'per serving',
    description: 'Roasted sweet potato chunks',
    emoji: '🍠',
    nutritionalBenefits: ['Beta carotene', 'Fiber', 'Vitamin A']
  },
  {
    id: 'brown-rice',
    name: 'Brown Rice',
    category: 'carb',
    price: 12,
    unit: 'per serving',
    description: 'Organic brown rice',
    emoji: '🍚',
    nutritionalBenefits: ['Complex carbs', 'Fiber', 'B vitamins']
  },
  {
    id: 'quinoa',
    name: 'Quinoa',
    category: 'carb',
    price: 18,
    unit: 'per serving',
    description: 'Protein-rich quinoa',
    emoji: '🌾',
    nutritionalBenefits: ['Complete protein', 'Gluten-free', 'Minerals']
  },
  {
    id: 'pumpkin',
    name: 'Pumpkin',
    category: 'carb',
    price: 14,
    unit: 'per serving',
    description: 'Fresh pumpkin puree',
    emoji: '🎃',
    nutritionalBenefits: ['Fiber', 'Digestive health', 'Vitamin A']
  },
  {
    id: 'oats',
    name: 'Steel-Cut Oats',
    category: 'carb',
    price: 10,
    unit: 'per serving',
    description: 'Gluten-free steel-cut oats',
    emoji: '🌾',
    nutritionalBenefits: ['Soluble fiber', 'Heart health', 'Sustained energy']
  }
];

export const vegetables: MealIngredient[] = [
  {
    id: 'carrots',
    name: 'Carrots',
    category: 'vegetable',
    price: 8,
    unit: 'per serving',
    description: 'Fresh diced carrots',
    emoji: '🥕',
    nutritionalBenefits: ['Beta carotene', 'Fiber', 'Eye health']
  },
  {
    id: 'green-beans',
    name: 'Green Beans',
    category: 'vegetable',
    price: 10,
    unit: 'per serving',
    description: 'Steamed green beans',
    emoji: '🫘',
    nutritionalBenefits: ['Vitamins K & C', 'Fiber', 'Low calories']
  },
  {
    id: 'broccoli',
    name: 'Broccoli',
    category: 'vegetable',
    price: 12,
    unit: 'per serving',
    description: 'Fresh broccoli florets',
    emoji: '🥦',
    nutritionalBenefits: ['Vitamin C', 'Antioxidants', 'Fiber']
  },
  {
    id: 'spinach',
    name: 'Spinach',
    category: 'vegetable',
    price: 9,
    unit: 'per serving',
    description: 'Fresh baby spinach',
    emoji: '🥬',
    nutritionalBenefits: ['Iron', 'Folate', 'Vitamin K']
  },
  {
    id: 'peas',
    name: 'Green Peas',
    category: 'vegetable',
    price: 11,
    unit: 'per serving',
    description: 'Sweet green peas',
    emoji: '🟢',
    nutritionalBenefits: ['Protein', 'Fiber', 'Vitamin A']
  },
  {
    id: 'zucchini',
    name: 'Zucchini',
    category: 'vegetable',
    price: 7,
    unit: 'per serving',
    description: 'Fresh diced zucchini',
    emoji: '🥒',
    nutritionalBenefits: ['Low calories', 'Hydration', 'Vitamin C']
  }
];

export const addons: MealIngredient[] = [
  {
    id: 'bone-broth',
    name: 'Bone Broth',
    category: 'addon',
    price: 25,
    unit: 'per serving',
    description: 'Slow-simmered bone broth',
    emoji: '🍲',
    nutritionalBenefits: ['Collagen', 'Joint health', 'Hydration']
  },
  {
    id: 'coconut-oil',
    name: 'Coconut Oil',
    category: 'addon',
    price: 15,
    unit: 'per serving',
    description: 'Cold-pressed coconut oil',
    emoji: '🥥',
    nutritionalBenefits: ['MCT oils', 'Coat health', 'Energy boost']
  },
  {
    id: 'olive-oil',
    name: 'Extra Virgin Olive Oil',
    category: 'addon',
    price: 18,
    unit: 'per serving',
    description: 'Premium extra virgin olive oil',
    emoji: '🫒',
    nutritionalBenefits: ['Healthy fats', 'Antioxidants', 'Skin health']
  },
  {
    id: 'turmeric',
    name: 'Turmeric',
    category: 'addon',
    price: 12,
    unit: 'per serving',
    description: 'Organic turmeric powder',
    emoji: '🟡',
    nutritionalBenefits: ['Anti-inflammatory', 'Joint health', 'Antioxidants']
  },
  {
    id: 'probiotics',
    name: 'Probiotic Blend',
    category: 'addon',
    price: 20,
    unit: 'per serving',
    description: 'Pet-specific probiotic cultures',
    emoji: '🦠',
    nutritionalBenefits: ['Digestive health', 'Immune support', 'Gut flora']
  }
];