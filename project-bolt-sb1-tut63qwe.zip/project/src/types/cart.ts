export interface CartItem {
  id: string;
  title: string;
  size: string;
  price: number;
  quantity: number;
  emoji: string;
  meatType: string;
  customIngredients?: {
    protein?: string;
    carbs?: string[];
    vegetables?: string[];
    addons?: string[];
  };
}

export interface CartContextType {
  items: CartItem[];
  addToCart: (item: Omit<CartItem, 'id' | 'quantity'>) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  getTotalItems: () => number;
  getTotalPrice: () => number;
  clearCart: () => void;
}