export interface MealIngredient {
  id: string;
  name: string;
  category: 'protein' | 'carb' | 'vegetable' | 'addon';
  price: number;
  unit: string;
  description: string;
  emoji: string;
  nutritionalBenefits: string[];
}

export interface CustomMeal {
  id: string;
  name: string;
  size: 'small' | 'medium' | 'large';
  protein: MealIngredient;
  carbs: MealIngredient[];
  vegetables: MealIngredient[];
  addons: MealIngredient[];
  totalPrice: number;
  servingSize: string;
}

export interface MealSize {
  id: string;
  name: string;
  weight: string;
  servings: string;
  multiplier: number;
}