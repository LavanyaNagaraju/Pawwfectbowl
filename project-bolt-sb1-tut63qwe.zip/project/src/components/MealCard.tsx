import React from 'react';
import { Check, Plus } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface MealOption {
  size: string;
  meatCost: number;
  otherCosts: number;
  totalCost: number;
  suggestedPrice: number;
}

interface MealCardProps {
  title: string;
  emoji: string;
  description: string;
  meals: MealOption[];
  gradient: string;
}

export default function MealCard({ title, emoji, description, meals, gradient }: MealCardProps) {
  const { addToCart } = useCart();

  const handleAddToCart = (meal: MealOption) => {
    addToCart({
      title,
      emoji,
      size: meal.size,
      price: meal.suggestedPrice,
      meatType: title.toLowerCase().replace('-based meals', ''),
    });
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-shadow duration-300">
      <div className={`${gradient} p-6 text-white`}>
        <div className="flex items-center space-x-3 mb-2">
          <span className="text-3xl">{emoji}</span>
          <h3 className="text-2xl font-bold">{title}</h3>
        </div>
        <p className="text-white/90">{description}</p>
      </div>
      
      <div className="p-6">
        <div className="space-y-4">
          {meals.map((meal, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-orange-300 transition-colors">
              <div className="flex justify-between items-center mb-3">
                <span className="text-lg font-semibold text-gray-900">{meal.size}</span>
                <div className="text-right">
                  <div className="text-2xl font-bold text-orange-500">₹{meal.suggestedPrice}</div>
                  <div className="text-sm text-gray-500 line-through">₹{meal.totalCost}</div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm text-gray-600 mb-3">
                <div>Meat Cost: ₹{meal.meatCost.toFixed(2)}</div>
                <div>Other Costs: ₹{meal.otherCosts}</div>
              </div>
              
              <button 
                onClick={() => handleAddToCart(meal)}
                className="w-full bg-orange-500 text-white py-2 rounded-lg hover:bg-orange-600 transition-colors font-medium flex items-center justify-center space-x-2 group"
              >
                <Plus className="h-4 w-4 group-hover:scale-110 transition-transform" />
                <span>Add to Cart</span>
              </button>
            </div>
          ))}
        </div>
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Check className="h-4 w-4 text-green-500" />
            <span>Bone-in for natural nutrition</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600 mt-1">
            <Check className="h-4 w-4 text-green-500" />
            <span>85% markup for premium quality</span>
          </div>
        </div>
      </div>
    </div>
  );
}