import React from 'react';
import { Truck, Clock, Shield } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="bg-gradient-to-br from-orange-50 to-amber-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Fresh, Healthy Meals for Your
            <span className="text-orange-500 block">Beloved Pets</span>
          </h1>
          <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto">
            Premium quality, bone-in meals made with the finest ingredients. 
            Delivered fresh to your doorstep for your furry family members.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <div className="flex flex-col items-center">
              <div className="bg-white p-4 rounded-full shadow-lg mb-4">
                <Truck className="h-8 w-8 text-orange-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Free Delivery</h3>
              <p className="text-gray-600 text-center">Fresh meals delivered right to your door at no extra cost</p>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="bg-white p-4 rounded-full shadow-lg mb-4">
                <Clock className="h-8 w-8 text-orange-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Always Fresh</h3>
              <p className="text-gray-600 text-center">Prepared daily with the highest quality ingredients</p>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="bg-white p-4 rounded-full shadow-lg mb-4">
                <Shield className="h-8 w-8 text-orange-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Vet Approved</h3>
              <p className="text-gray-600 text-center">Nutritionally balanced meals approved by veterinarians</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}