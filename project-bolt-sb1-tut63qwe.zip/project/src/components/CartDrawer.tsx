import React from 'react';
import { X, Plus, Minus, ShoppingBag, Utensils } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CartDrawer({ isOpen, onClose }: CartDrawerProps) {
  const { items, updateQuantity, removeFromCart, getTotalPrice, clearCart } = useCart();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose}></div>
      
      <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl">
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between border-b border-gray-200 px-6 py-4">
            <h2 className="text-lg font-semibold text-gray-900">Your Cart</h2>
            <button
              onClick={onClose}
              className="rounded-full p-2 hover:bg-gray-100 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-6 py-4">
            {items.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-500">
                <ShoppingBag className="h-16 w-16 mb-4" />
                <p className="text-lg font-medium">Your cart is empty</p>
                <p className="text-sm">Add some delicious meals for your pet!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-lg">{item.emoji}</span>
                        <div>
                          <h3 className="font-medium text-gray-900">{item.title}</h3>
                          <p className="text-sm text-gray-600">{item.size}</p>
                          {item.meatType === 'custom' && (
                            <div className="flex items-center space-x-1 mt-1">
                              <Utensils className="h-3 w-3 text-orange-500" />
                              <span className="text-xs text-orange-600 font-medium">Custom Recipe</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-red-500 hover:text-red-700 transition-colors"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                    
                    {item.customIngredients && (
                      <div className="mb-3 p-2 bg-orange-50 rounded text-xs">
                        <div className="space-y-1">
                          {item.customIngredients.protein && (
                            <div><span className="font-medium">Protein:</span> {item.customIngredients.protein}</div>
                          )}
                          {item.customIngredients.carbs && item.customIngredients.carbs.length > 0 && (
                            <div><span className="font-medium">Carbs:</span> {item.customIngredients.carbs.join(', ')}</div>
                          )}
                          {item.customIngredients.vegetables && item.customIngredients.vegetables.length > 0 && (
                            <div><span className="font-medium">Veggies:</span> {item.customIngredients.vegetables.join(', ')}</div>
                          )}
                          {item.customIngredients.addons && item.customIngredients.addons.length > 0 && (
                            <div><span className="font-medium">Add-ons:</span> {item.customIngredients.addons.join(', ')}</div>
                          )}
                        </div>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="rounded-full p-1 hover:bg-gray-100 transition-colors"
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="w-8 text-center font-medium">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="rounded-full p-1 hover:bg-gray-100 transition-colors"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-orange-500">
                          ₹{(item.price * item.quantity).toLocaleString()}
                        </div>
                        <div className="text-xs text-gray-500">
                          ₹{item.price} each
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {items.length > 0 && (
            <div className="border-t border-gray-200 px-6 py-4">
              <div className="flex justify-between items-center mb-4">
                <span className="text-lg font-semibold text-gray-900">Total:</span>
                <span className="text-2xl font-bold text-orange-500">
                  ₹{getTotalPrice().toLocaleString()}
                </span>
              </div>
              
              <div className="space-y-2">
                <button className="w-full bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 transition-colors font-semibold">
                  Proceed to Checkout
                </button>
                <button
                  onClick={clearCart}
                  className="w-full border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Clear Cart
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}