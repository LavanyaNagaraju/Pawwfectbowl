import React, { useState } from 'react';
import MealCard from './MealCard';
import MealBuilder from './MealBuilder';

const chickenMeals = [
  { size: 'Small', meatCost: 12.00, otherCosts: 20, totalCost: 37.00, suggestedPrice: 68 },
  { size: 'Medium', meatCost: 18.00, otherCosts: 25, totalCost: 48.00, suggestedPrice: 89 },
  { size: 'Large', meatCost: 30.00, otherCosts: 30, totalCost: 65.00, suggestedPrice: 120 },
];

const fishMeals = [
  { size: 'Small', meatCost: 28.00, otherCosts: 20, totalCost: 53.00, suggestedPrice: 98 },
  { size: 'Medium', meatCost: 42.00, otherCosts: 25, totalCost: 72.00, suggestedPrice: 133 },
  { size: 'Large', meatCost: 70.00, otherCosts: 30, totalCost: 105.00, suggestedPrice: 194 },
];

const lambMeals = [
  { size: 'Small', meatCost: 72.00, otherCosts: 20, totalCost: 97.00, suggestedPrice: 179 },
  { size: 'Medium', meatCost: 108.00, otherCosts: 25, totalCost: 138.00, suggestedPrice: 255 },
  { size: 'Large', meatCost: 180.00, otherCosts: 30, totalCost: 215.00, suggestedPrice: 398 },
];

export default function MealsSection() {
  const [activeTab, setActiveTab] = useState<'premade' | 'custom'>('custom');

  return (
    <section id="meals" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Choose Your Pet's Perfect Meal
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Select from our pre-made favorites or build a completely custom meal 
            tailored to your pet's specific needs and preferences.
          </p>
          
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => setActiveTab('custom')}
              className={`px-8 py-3 rounded-full font-semibold transition-all ${
                activeTab === 'custom'
                  ? 'bg-orange-500 text-white shadow-lg'
                  : 'bg-white text-gray-700 border border-gray-300 hover:border-orange-300'
              }`}
            >
              🎨 Build Custom Meal
            </button>
            <button
              onClick={() => setActiveTab('premade')}
              className={`px-8 py-3 rounded-full font-semibold transition-all ${
                activeTab === 'premade'
                  ? 'bg-orange-500 text-white shadow-lg'
                  : 'bg-white text-gray-700 border border-gray-300 hover:border-orange-300'
              }`}
            >
              ⚡ Quick Select
            </button>
          </div>
        </div>

        {activeTab === 'custom' ? (
          <MealBuilder />
        ) : (
          <>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <MealCard
                title="Chicken-Based Meals"
                emoji="🐔"
                description="Lean protein-rich meals perfect for everyday nutrition"
                meals={chickenMeals}
                gradient="bg-gradient-to-br from-yellow-500 to-orange-500"
              />
              
              <MealCard
                title="Fish-Based Meals"
                emoji="🐟"
                description="Omega-3 rich meals for healthy skin and shiny coat"
                meals={fishMeals}
                gradient="bg-gradient-to-br from-blue-500 to-cyan-500"
              />
              
              <MealCard
                title="Lamb-Based Meals"
                emoji="🐑"
                description="Premium protein for the most discerning pets"
                meals={lambMeals}
                gradient="bg-gradient-to-br from-purple-500 to-pink-500"
              />
            </div>

            <div className="text-center mt-12">
              <div className="bg-white rounded-lg p-6 shadow-lg inline-block">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Why Choose Bone-In Meals?</h3>
                <p className="text-gray-600 max-w-2xl">
                  Bone-in meals provide natural calcium, promote dental health, and satisfy your pet's 
                  natural instinct to chew. All our bones are safely prepared and vet-approved.
                </p>
              </div>
            </div>
          </>
        )}
      </div>
    </section>
  );
}