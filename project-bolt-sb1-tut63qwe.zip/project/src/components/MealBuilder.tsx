import React, { useState } from 'react';
import { Plus, Minus, Check, Info } from 'lucide-react';
import { MealIngredient, CustomMeal, MealSize } from '../types/meal';
import { proteins, carbs, vegetables, addons, mealSizes } from '../data/ingredients';
import { useCart } from '../context/CartContext';

export default function MealBuilder() {
  const { addToCart } = useCart();
  const [selectedSize, setSelectedSize] = useState<MealSize>(mealSizes[0]);
  const [selectedProtein, setSelectedProtein] = useState<MealIngredient | null>(null);
  const [selectedCarbs, setSelectedCarbs] = useState<MealIngredient[]>([]);
  const [selectedVegetables, setSelectedVegetables] = useState<MealIngredient[]>([]);
  const [selectedAddons, setSelectedAddons] = useState<MealIngredient[]>([]);
  const [mealName, setMealName] = useState('');

  const calculateTotalPrice = () => {
    const basePrice = 20; // Base preparation cost
    const proteinPrice = selectedProtein ? selectedProtein.price * selectedSize.multiplier : 0;
    const carbsPrice = selectedCarbs.reduce((sum, carb) => sum + (carb.price * selectedSize.multiplier), 0);
    const veggiesPrice = selectedVegetables.reduce((sum, veggie) => sum + (veggie.price * selectedSize.multiplier), 0);
    const addonsPrice = selectedAddons.reduce((sum, addon) => sum + (addon.price * selectedSize.multiplier), 0);
    
    return Math.round((basePrice + proteinPrice + carbsPrice + veggiesPrice + addonsPrice) * selectedSize.multiplier);
  };

  const toggleIngredient = (ingredient: MealIngredient, selectedList: MealIngredient[], setSelectedList: React.Dispatch<React.SetStateAction<MealIngredient[]>>) => {
    const isSelected = selectedList.some(item => item.id === ingredient.id);
    if (isSelected) {
      setSelectedList(selectedList.filter(item => item.id !== ingredient.id));
    } else {
      setSelectedList([...selectedList, ingredient]);
    }
  };

  const canAddToCart = () => {
    return selectedProtein && selectedCarbs.length > 0 && selectedVegetables.length > 0;
  };

  const handleAddToCart = () => {
    if (!canAddToCart()) return;

    const customMeal: CustomMeal = {
      id: `custom-${Date.now()}`,
      name: mealName || `Custom ${selectedProtein!.name} Bowl`,
      size: selectedSize.id as 'small' | 'medium' | 'large',
      protein: selectedProtein!,
      carbs: selectedCarbs,
      vegetables: selectedVegetables,
      addons: selectedAddons,
      totalPrice: calculateTotalPrice(),
      servingSize: selectedSize.weight
    };

    addToCart({
      title: customMeal.name,
      emoji: selectedProtein!.emoji,
      size: selectedSize.name,
      price: customMeal.totalPrice,
      meatType: 'custom'
    });

    // Reset form
    setSelectedProtein(null);
    setSelectedCarbs([]);
    setSelectedVegetables([]);
    setSelectedAddons([]);
    setMealName('');
  };

  const IngredientCard = ({ 
    ingredient, 
    isSelected, 
    onToggle, 
    isRequired = false 
  }: { 
    ingredient: MealIngredient; 
    isSelected: boolean; 
    onToggle: () => void;
    isRequired?: boolean;
  }) => (
    <div
      onClick={onToggle}
      className={`border-2 rounded-lg p-4 cursor-pointer transition-all duration-200 ${
        isSelected
          ? 'border-orange-500 bg-orange-50 shadow-md'
          : 'border-gray-200 hover:border-orange-300 hover:shadow-sm'
      }`}
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center space-x-2">
          <span className="text-2xl">{ingredient.emoji}</span>
          <div>
            <h3 className="font-semibold text-gray-900">{ingredient.name}</h3>
            <p className="text-sm text-gray-600">{ingredient.description}</p>
          </div>
        </div>
        <div className="text-right">
          <div className="text-lg font-bold text-orange-500">
            ₹{Math.round(ingredient.price * selectedSize.multiplier)}
          </div>
          <div className="text-xs text-gray-500">{ingredient.unit}</div>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-1 mb-2">
        {ingredient.nutritionalBenefits.map((benefit, index) => (
          <span key={index} className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
            {benefit}
          </span>
        ))}
      </div>
      
      <div className="flex items-center justify-between">
        {isRequired && !isSelected && (
          <span className="text-xs text-red-500 font-medium">Required</span>
        )}
        {isSelected && (
          <div className="flex items-center space-x-1 text-orange-500">
            <Check className="h-4 w-4" />
            <span className="text-sm font-medium">Selected</span>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Build Your Pet's Perfect Meal
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Create a customized meal tailored to your pet's preferences and nutritional needs. 
            Choose from premium proteins, healthy carbs, fresh vegetables, and beneficial add-ons.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Meal Name */}
          <div className="mb-8">
            <label className="block text-lg font-semibold text-gray-900 mb-2">
              Name Your Meal (Optional)
            </label>
            <input
              type="text"
              value={mealName}
              onChange={(e) => setMealName(e.target.value)}
              placeholder="e.g., Bella's Favorite Bowl"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            />
          </div>

          {/* Size Selection */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Choose Size</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {mealSizes.map((size) => (
                <div
                  key={size.id}
                  onClick={() => setSelectedSize(size)}
                  className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                    selectedSize.id === size.id
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                >
                  <h4 className="font-semibold text-gray-900">{size.name}</h4>
                  <p className="text-sm text-gray-600">{size.weight}</p>
                  <p className="text-xs text-gray-500">{size.servings}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Protein Selection */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Choose Protein <span className="text-red-500">*</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {proteins.map((protein) => (
                <IngredientCard
                  key={protein.id}
                  ingredient={protein}
                  isSelected={selectedProtein?.id === protein.id}
                  onToggle={() => setSelectedProtein(protein)}
                  isRequired={true}
                />
              ))}
            </div>
          </div>

          {/* Carbs Selection */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Choose Carbohydrates <span className="text-red-500">*</span>
              <span className="text-sm font-normal text-gray-600 ml-2">(Select 1-2)</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {carbs.map((carb) => (
                <IngredientCard
                  key={carb.id}
                  ingredient={carb}
                  isSelected={selectedCarbs.some(item => item.id === carb.id)}
                  onToggle={() => toggleIngredient(carb, selectedCarbs, setSelectedCarbs)}
                  isRequired={selectedCarbs.length === 0}
                />
              ))}
            </div>
          </div>

          {/* Vegetables Selection */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Choose Vegetables <span className="text-red-500">*</span>
              <span className="text-sm font-normal text-gray-600 ml-2">(Select 2-3)</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {vegetables.map((vegetable) => (
                <IngredientCard
                  key={vegetable.id}
                  ingredient={vegetable}
                  isSelected={selectedVegetables.some(item => item.id === vegetable.id)}
                  onToggle={() => toggleIngredient(vegetable, selectedVegetables, setSelectedVegetables)}
                  isRequired={selectedVegetables.length === 0}
                />
              ))}
            </div>
          </div>

          {/* Add-ons Selection */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Optional Add-ons
              <span className="text-sm font-normal text-gray-600 ml-2">(Enhance nutrition & flavor)</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {addons.map((addon) => (
                <IngredientCard
                  key={addon.id}
                  ingredient={addon}
                  isSelected={selectedAddons.some(item => item.id === addon.id)}
                  onToggle={() => toggleIngredient(addon, selectedAddons, setSelectedAddons)}
                />
              ))}
            </div>
          </div>

          {/* Summary and Add to Cart */}
          <div className="border-t border-gray-200 pt-8">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Meal Summary</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Selected Ingredients:</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    {selectedProtein && <li>• {selectedProtein.name}</li>}
                    {selectedCarbs.map(carb => <li key={carb.id}>• {carb.name}</li>)}
                    {selectedVegetables.map(veggie => <li key={veggie.id}>• {veggie.name}</li>)}
                    {selectedAddons.map(addon => <li key={addon.id}>• {addon.name}</li>)}
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Nutritional Benefits:</h4>
                  <div className="flex flex-wrap gap-1">
                    {[
                      ...(selectedProtein?.nutritionalBenefits || []),
                      ...selectedCarbs.flatMap(carb => carb.nutritionalBenefits),
                      ...selectedVegetables.flatMap(veggie => veggie.nutritionalBenefits),
                      ...selectedAddons.flatMap(addon => addon.nutritionalBenefits)
                    ].slice(0, 8).map((benefit, index) => (
                      <span key={index} className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                        {benefit}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-gray-600">
                    Size: {selectedSize.name} ({selectedSize.weight})
                  </div>
                  <div className="text-2xl font-bold text-orange-500">
                    Total: ₹{calculateTotalPrice()}
                  </div>
                </div>
                
                <button
                  onClick={handleAddToCart}
                  disabled={!canAddToCart()}
                  className={`px-8 py-3 rounded-lg font-semibold transition-all ${
                    canAddToCart()
                      ? 'bg-orange-500 text-white hover:bg-orange-600 shadow-lg hover:shadow-xl'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  {canAddToCart() ? 'Add to Cart' : 'Select Required Ingredients'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}