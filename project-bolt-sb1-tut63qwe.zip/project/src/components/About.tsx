import React from 'react';
import { Award, Users, Leaf, Heart } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Why Pet Parents Choose PawfectBowl
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              We're passionate about providing the highest quality nutrition for your furry family members. 
              Every meal is crafted with love, using only the finest ingredients and prepared fresh daily.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex items-start space-x-3">
                <Award className="h-6 w-6 text-orange-500 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900">Premium Quality</h3>
                  <p className="text-gray-600 text-sm">Only the finest ingredients make it into our meals</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Users className="h-6 w-6 text-orange-500 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900">Expert Team</h3>
                  <p className="text-gray-600 text-sm">Veterinarians and pet nutritionists guide our recipes</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Leaf className="h-6 w-6 text-orange-500 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900">Natural Ingredients</h3>
                  <p className="text-gray-600 text-sm">No artificial preservatives or fillers</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Heart className="h-6 w-6 text-orange-500 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900">Made with Love</h3>
                  <p className="text-gray-600 text-sm">Every meal is prepared with care and attention</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="bg-gradient-to-br from-orange-100 to-amber-100 rounded-2xl p-8">
              <img 
                src="https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=600" 
                alt="Happy pets eating" 
                className="rounded-lg shadow-lg w-full h-64 object-cover"
              />
              <div className="mt-6 text-center">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <div className="text-2xl font-bold text-orange-500">1000+</div>
                    <div className="text-sm text-gray-600">Happy Pets</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-orange-500">500+</div>
                    <div className="text-sm text-gray-600">Families</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-orange-500">5★</div>
                    <div className="text-sm text-gray-600">Rating</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}