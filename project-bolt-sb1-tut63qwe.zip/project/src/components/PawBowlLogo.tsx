import React from 'react';

interface PawBowlLogoProps {
  className?: string;
}

export default function PawBowlLogo({ className = "h-8 w-8" }: PawBowlLogoProps) {
  return (
    <div className={`${className} relative`}>
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        {/* Bowl */}
        <ellipse
          cx="50"
          cy="75"
          rx="35"
          ry="8"
          fill="currentColor"
          className="text-orange-500"
        />
        <path
          d="M15 75 Q15 85 25 90 Q37.5 95 50 95 Q62.5 95 75 90 Q85 85 85 75"
          fill="currentColor"
          className="text-orange-600"
        />
        
        {/* Main paw pad */}
        <ellipse
          cx="50"
          cy="55"
          rx="12"
          ry="15"
          fill="currentColor"
          className="text-gray-700"
        />
        
        {/* Toe pads */}
        <ellipse
          cx="35"
          cy="35"
          rx="6"
          ry="8"
          fill="currentColor"
          className="text-gray-700"
          transform="rotate(-15 35 35)"
        />
        <ellipse
          cx="45"
          cy="28"
          rx="6"
          ry="8"
          fill="currentColor"
          className="text-gray-700"
        />
        <ellipse
          cx="55"
          cy="28"
          rx="6"
          ry="8"
          fill="currentColor"
          className="text-gray-700"
        />
        <ellipse
          cx="65"
          cy="35"
          rx="6"
          ry="8"
          fill="currentColor"
          className="text-gray-700"
          transform="rotate(15 65 35)"
        />
        
        {/* Shadow/depth effect */}
        <ellipse
          cx="50"
          cy="77"
          rx="30"
          ry="6"
          fill="currentColor"
          className="text-orange-400 opacity-50"
        />
      </svg>
    </div>
  );
}